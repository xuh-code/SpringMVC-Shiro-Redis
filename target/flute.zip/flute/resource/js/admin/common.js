/**
 * Created by Zero on 2017/8/23.
 */
function Notify(message, position, timeout, theme, icon, closable) {
    toastr.options.positionClass = 'toast-' + position;
    toastr.options.extendedTimeOut = 0; //1000;
    toastr.options.timeOut = timeout;
    toastr.options.closeButton = closable;
    toastr.options.iconClass = icon + ' toast-' + theme;
    toastr['custom'](message);
}
//获取时间格式
function getTime(date) {
    var date = new Date(date);
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    month = month > 9 ? month : "0" + month;
    var day = date.getDate() > 9 ? date.getDate() : "0" + date.getDate();
    var week_day = date.getDay();
    var hour = date.getHours() > 9 ? date.getHours() : '0' + date.getHours();
    var min = date.getMinutes() > 9 ? date.getMinutes() : '0' + date.getMinutes();
    var s = date.getSeconds() > 9 ? date.getSeconds() : '0' + date.getSeconds();

    return year + '-' + month + '-' + day + ' ' + hour + ':' + min + ':' + s;
}
function chackForm(){
    $('.edit-btn').click(function () {
        var userName = $('#userName').val();
        var userPwd = $('#userPwd').val();
        var conUserPwd = $('#confirmUserPwd').val();
        if(userPwd .length < 6){
            Notify('密码不能少于6位!', 'top-right', '3000', 'warning', 'fa-warning', true);
            return false;
        }else if(userPwd != conUserPwd){
            Notify('两次密码输入不一致!', 'top-right', '3000', 'warning', 'fa-warning', true);
            return false;
        }
    });
    $('#editAdmin').submit(function () {
        // submit the form
        $(this).ajaxSubmit(function (data) {
            var code = data.code;
            if(code == 2){
                Notify('原密码错误', 'top-right', '3000', 'warning', 'fa-warning', true);
            }
            else if (code == 1) {
                $('#modal-success .modal-title').html('Success')
                $('#modal-success .modal-body').html('操作成功!!!')
                $('#modal-success').modal("show");

                window.location.href = '/admin/list';
            } else {
                $('#modal-warning .modal-title').html('Error');
                $('#modal-warning .modal-body').html('操作失败,请重新保存!!!');
                $('#modal-warning').modal("show");
            }
        });
        return false;
    });
}

function saveArticle() {
    $('.btn-submit').click(function () {
        var content = UE.getEditor('editor').getContent();
        var direction = UE.getEditor('editor').getContentTxt();
        if(direction.length > 150){
            direction = direction.substring(0,150);
        }
        if ($('#type').val() == '') {
            Notify('请选择新闻分类', 'top-right', '3000', 'warning', 'fa-warning', true);
            return false;
        } else if ($('#type').val() == '4') {
            if ($('#faceImg').val() == '') {
                Notify('请上传会员封面照片', 'top-right', '3000', 'warning', 'fa-warning', true);
                return false;
            }
            $('#direction').val(direction);
            $('#content').val(content);
        } else {
            if ($('#title').val() == '') {
                Notify('请输入文章标题', 'top-right', '3000', 'warning', 'fa-warning', true);
                return false;
            } else {
                if (content == '') {
                    Notify('请输入文章正文内容', 'top-right', '3000', 'warning', 'fa-warning', true);
                    return false;
                } else {
                    $('#direction').val(direction);
                    $('#content').val(content);
                }
            }
        }
    });

    /*选择图片的的插件*/
    var up_file = document.getElementById('upload-file');
    var file_name = document.getElementById('file-name');
    var product_img = document.getElementById('product-img');
    up_file.onchange = function () {
        file_name.innerHTML = '';
        product_img.innerHTML = '';
        for (var i = 0; i < this.files.length; i++) {
            file_name.innerHTML += this.files[i].name + '&nbsp;&nbsp;&nbsp;';
            var blob = URL.createObjectURL(this.files[i]);
            product_img.innerHTML += '<div style="display:inline-block; margin:5px 5px 0 0; overflow:hidden; width:120px; height:120px; border:1px solid #ccc; text-align:center; line-height:120px; font-size:0; "><img src="' + blob + '" style="max-width:110px;"></div>';
        }
    }
    $('#upload-file').change(function(){
        if($('#upload-file')[0].files.length>0){
            for(var i=0; i<$('#upload-file')[0].files.length; i++){
                var formData=new FormData();
                formData.append('file', $('#upload-file')[0].files[i]);
                $.ajax({
                    url:'/admin/faceImgUpload',
                    type:'POST',
                    data:formData,
                    dataType: 'json',
                    async:false,
                    contentType:false,
                    processData:false,
                    success: function(data) {
                        //回调结果的处理
                        file_name.innerHTML = data.fileName + '&nbsp;&nbsp;&nbsp;';
                        $('#faceImg').val(data.fileName);
                    }
                });
            }
        }
    });




}

function submit_click() {
    $('#newsForm').submit(function () {
        // submit the form
        $(this).ajaxSubmit(function (data) {
            var code = data.code;
            if (code == 1) {
                $('#modal-success .modal-title').html('Success')
                $('#modal-success .modal-body').html('操作成功!!!')
                $('#modal-success').modal("show");

                window.location.href = '/admin/list';
            } else {
                $('#modal-warning .modal-title').html('Error');
                $('#modal-warning .modal-body').html('操作失败,请重新保存!!!');
                $('#modal-warning').modal("show");
            }
        });
        return false;
    });
}
function deleteArticle(id) {
    $.ajax({
        type: 'POST',
        url: 'admin/delArticle',
        data: {id: id},
        dataType: 'json',
        success: function (data) {
            var code = data.code;
            if (code == 1) {
                $('#modal-success .modal-title').html('Success')
                $('#modal-success .modal-body').html('操作成功!!!')
                $('#modal-success').modal("show");
                window.location.href = '/admin/list';
            } else {
                $('#modal-warning .modal-title').html('Error');
                $('#modal-warning .modal-body').html('删除失败!!!');
                $('#modal-warning').modal("show");
            }
        }
    });
}

var div = '<tr>\
                <td>#id#</td>\
                <td>#title#</td>\
                <td>#userName#</td>\
                <td>#time#</td>\
                <td>\
                    <a href="/html/#year#/#monday#/#id#" target="_blank" class="btn btn-info btn-xs edit">\
                        <i class="fa  fa-search"></i> 查看\
                    </a>&nbsp;&nbsp;\
                    <a href="/admin/edit/#id#" class="btn btn-xs btn-darkorange">\
                        <i class="fa fa-edit"></i>编辑\
                    </a>&nbsp;&nbsp;\
                    <a href="javascript:void(0);" class="btn btn-danger btn-xs delete delNews" data-id = "#id#">\
                        <i class="fa fa-trash-o"></i>删除\
                    </a>\
                </td>\
            </tr>';


function getArticleByPage(page) {
    $.ajax({
        type: 'POST',
        url: 'admin/getArticleListByPage',
        data: {page: page},
        dataType: 'json',
        success: function (data) {
            $("tbody").html("");
            var news = data.news;
            if(data.login_status == 300){
                window.location.href = "/admin"
            }else {
                if (news.length < 1) {
                    trs = '<tr>\
                            <td colspan="7" style="text-align: center;color: #C1C1C1;">\
                            没有查到数据吆!\
                        </td>\
                        </tr>';
                    $("tbody").html(trs);
                } else {
                    for (var i = 0; i < news.length; i++) {
                        var id = news[i].id;
                        var title = news[i].title;
                        var date = new Date(news[i].createTime);
                        var time = getTime(date);
                        var year = date.getFullYear();
                        var mon = date.getMonth() + 1;
                        mon = mon > 9 ? mon : "0" + mon;
                        var day = date.getDate() > 9 ? date.getDate() : "0" + date.getDate();
                        var userName = news[i].userName;

                        var trs = div;

                        trs = trs.replace(/#id#/g, id);
                        trs = trs.replace(/#title#/g, title);
                        trs = trs.replace(/#userName#/g, userName);
                        trs = trs.replace(/#time#/g, time);
                        trs = trs.replace(/#year#/g, year);
                        trs = trs.replace(/#monday#/g, mon+ '' +day);
                        $("tbody").append(trs);
                    }
                }
            }
            $("html, body").scrollTop(0).animate({scrollTop: $(".page-body").offset().top},1000);
        }
    });
}
function backup() {
    //备份
    $('#backup').submit(function () {
        // submit the form
        $(this).ajaxSubmit(function (data) {
            var code = data.code;
            if (code == 1) {
                $('#modal-success .modal-title').html('Success')
                $('#modal-success .modal-body').html('操作成功!!!')
                $('#modal-success').modal("show");

                setTimeout("window.location.href = '/admin/dataBase'",1000);
            } else {
                $('#modal-warning .modal-title').html('Error');
                $('#modal-warning .modal-body').html('操作失败,请重新保存!!!');
                $('#modal-warning').modal("show");
            }
        });
        return false;
    });

    //还原
    $(".restore_btn").click(function () {
        var file = $(this).data('file');
        $('#myConfirm p').html('将覆盖当前数据库，是否恢复？');
        bootbox.dialog({
            message: $('#myConfirm').html(),
            title: "还原数据库",
            className: "modal-darkorange",
            onEscape: function() {},
            backdrop: false,
            buttons: {
                "取消": {
                    className: "btn-blue",
                    callback: function () { }
                },
                "确定": {
                    className: "btn-danger",
                    callback: function () {
                        $.ajax({
                            type: 'POST',
                            url: '/admin/dataBase/restore',
                            data: {fileName: file},
                            dataType: 'json',
                            success: function (data) {
                                var code = data.code;
                                if(code == -1){
                                    $('#modal-warning .modal-title').html('Error');
                                    $('#modal-warning .modal-body').html('备份文件找不到');
                                    $('#modal-warning').modal("show");
                                }else if(code == 0){
                                    $('#modal-warning .modal-title').html('Error');
                                    $('#modal-warning .modal-body').html('操作失败,请重新进行还原');
                                    $('#modal-warning').modal("show");
                                }else{
                                    $('#modal-success .modal-title').html('Success')
                                    $('#modal-success .modal-body').html('操作成功!!!')
                                    $('#modal-success').modal("show");
                                }
                            }
                        });
                    }
                }
            }
        });
    });

    //删除 备份数据库
    $(document).on('click',".del_database",function(e){
        var file = $(this).data("file");
        $('#myConfirm p').html('删除不可恢复，确定删除？');
        bootbox.dialog({
            message: $('#myConfirm').html(),
            title: "删除备份文件",
            className: "modal-darkorange",
            onEscape: function() {},
            backdrop: false,
            buttons: {
                "取消": {
                    className: "btn-blue",
                    callback: function () { }
                },
                "确定": {
                    className: "btn-danger",
                    callback: function () {
                        $.ajax({
                            type: 'POST',
                            url: '/admin/delDataBase',
                            data: {fileName: file},
                            dataType: 'json',
                            success: function (data) {
                                var code = data.code;
                                if(code == 0){
                                    $('#modal-warning .modal-title').html('Error');
                                    $('#modal-warning .modal-body').html('删除失败,文件不存在');
                                    $('#modal-warning').modal("show");
                                }else{
                                    $('#modal-success .modal-title').html('Success')
                                    $('#modal-success .modal-body').html('操作成功!!!')
                                    $('#modal-success').modal("show");
                                    window.location.href = '/admin/dataBase';
                                }
                            }
                        });
                    }
                }
            }
        });
    });
}