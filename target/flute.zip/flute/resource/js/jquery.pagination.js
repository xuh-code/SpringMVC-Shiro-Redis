;
(function($, window, document, undefined) {
    var defaults = {
        totalData: 0,
        showData: 0,
        pageCount: 9,
        current: 1,
        prevCls: 'prev',
        nextCls: 'next',
        prevContent: '<',
        nextContent: '>',
        activeCls: 'active',
        coping: false,
        homePage: '',
        endPage: '',
        count: 3,
        jump: false,
        jumpIptCls: 'jump-ipt',
        jumpBtnCls: 'jump-btn',
        jumpBtn: '跳转',
        callback: function() {}
    };
    var Pagination = function(element, options) {
        var opts = options,
            current, d = $(document),
            o = $(element);
        this.setTotalPage = function(page) {
            return opts.pageCount = page
        };
        this.getTotalPage = function() {
            var p = opts.totalData || opts.showData ? Math.ceil(parseInt(opts.totalData) / opts.showData) : opts.pageCount;
            return p
        };
        this.getCurrent = function() {
            return current
        };
        this.filling = function(index) {
            var html = '';
            current = index || opts.current;
            var pageCount = this.getTotalPage();
            if (current > 1) {
                html += '<a href="javascript:;" class="' + opts.prevCls + '">' + opts.prevContent + '</a>'
            } else {
                html += '<span class="first">' + opts.prevContent + '</span>'
            }
            if (current >= opts.count * 2 && current != 1 && pageCount != opts.count) {
                var home = opts.coping && opts.homePage ? opts.homePage : '1';
                html += opts.coping ? '<a href="javascript:;" data-page="1">' + home + '</a><span>...</span>' : ''
            }
            // var start = current - opts.count, end = current + opts.count;
            // ((start > 1 && current < opts.count) || current == 1) && end++;
            // (current > pageCount - opts.count && current >= pageCount) && start++;
            if(pageCount < (opts.count*2+1)){
                var start = 1;end = pageCount;
            }else if (current > pageCount - opts.count){
                var start = pageCount -4;
                var end = pageCount;
            }else if(current < opts.count + 2 && pageCount > (opts.count*2+1)){
                var start = 1;
                var end = 5;
            }else{
                var start = current - opts.count, end = current + opts.count;
                ((start > 1 && current < opts.count) || current == 1) && end++;
                (current > pageCount - opts.count && current >= pageCount) && start++;
            }

            // if(current > pageCount - opts.count){
            //     var start =
            // }
            for (; start <= end; start++) {
                if (start <= pageCount && start >= 1) {
                    if (start != current) {
                        html += '<a href="javascript:;" data-page="' + start + '">' + start + '</a>'
                    } else {
                        html += '<span class="' + opts.activeCls + '">' + start + '</span>'
                    }
                }
            }
            if (current + opts.count < pageCount && current >= 1 && pageCount > opts.count) {
                var end = opts.coping && opts.endPage ? opts.endPage : pageCount;
                html += opts.coping ? '<span>...</span><a href="javascript:;" data-page="' + pageCount + '">' + end + '</a>' : ''
            }
            if (current < pageCount) {
                html += '<a href="javascript:;" class="' + opts.nextCls + '">' + opts.nextContent + '</a>'
            } else {
                html += '<span class="last">' + opts.nextContent + '</span>'
            }
            html += opts.jump ? '<input type="text" class="' + opts.jumpIptCls + '"><a href="javascript:;" class="' + opts.jumpBtnCls + '">' + opts.jumpBtn + '</a>' : '';
            o.empty().html(html)
        };
        this.eventBind = function() {
            var self = this;
            var pageCount = this.getTotalPage();
            o.off().on('click', 'a', function() {
                if ($(this).hasClass(opts.nextCls)) {
                    var index = parseInt(o.find('.' + opts.activeCls).text()) + 1
                } else if ($(this).hasClass(opts.prevCls)) {
                    var index = parseInt(o.find('.' + opts.activeCls).text()) - 1
                } else if ($(this).hasClass(opts.jumpBtnCls)) {
                    if (o.find('.' + opts.jumpIptCls).val() !== '') {
                        var index = parseInt(o.find('.' + opts.jumpIptCls).val())
                    } else {
                        return
                    }
                } else {
                    var index = parseInt($(this).data('page'))
                }
                self.filling(index);
                typeof opts.callback === 'function' && opts.callback(self)
            });
            o.on('input propertychange', '.' + opts.jumpIptCls, function() {
                var t = $(this);
                var val = t.val();
                var reg = /[^\d]/g;
                if (reg.test(val)) {
                    t.val(val.replace(reg, ''))
                }(parseInt(val) > pageCount) && t.val(pageCount);
                if (parseInt(val) === 0) {
                    t.val(1)
                }
            });
            d.keydown(function(e) {
                var self = this;
                if (e.keyCode == 13 && o.find('.' + opts.jumpIptCls).val()) {
                    var index = parseInt(o.find('.' + opts.jumpIptCls).val());
                    self.filling(index);
                    typeof opts.callback === 'function' && opts.callback(self)
                }
            })
        };
        this.init = function() {
            this.filling(opts.current);
            this.eventBind()
        };
        this.init()
    };
    $.fn.pagination = function(parameter, callback) {
        if (typeof parameter == 'function') {
            callback = parameter;
            parameter = {}
        } else {
            parameter = parameter || {};
            callback = callback || function() {}
        }
        var options = $.extend({}, defaults, parameter);
        return this.each(function() {
            var pagination = new Pagination(this, options);
            callback(pagination)
        })
    }
})(jQuery, window, document);