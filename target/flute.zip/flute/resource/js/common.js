/**
 * Created by Zero on 2017/8/11.
 */
$(function () {
    $("html, body").scrollTop(0).animate({scrollTop: $("#to-top").offset().top},1000);

    //设置当前菜单
    $('#bs-example-navbar-collapse-1 a').eq($('#type').html()).css('color', "#a82a3b");
});

var article = '<li>\
    <a href="/html/#year#/#mon##day#/#id#" target="_blank" title="#title#">\
    #title#\
    </a>\
    <span>\
    #year#-#mon#-#day#\
</span>\
</li>\
<hr style="height:1px;border:none;border-top:1px dashed #CCCCCC;">';

function getNextArticle(type, page) {
    $.ajax({
        type : 'post',
        url : "/html/getNextArticle",
        data : {type : type,
                page : page * 15
        },
        datatype : 'json',
        success:function(data){
            $('.list_con_rightlist ul').html('');
            var news = data.news;
            for (var i = 0; i < news.length; i++){
                var id = news[i].id;
                var title = news[i].title;
                var time = news[i].createTime;
                var date = new Date(time);

                var mon=date.getMonth()+1;
                var day=date.getDate();
                var year=date.getFullYear();

                if(mon < 10){
                    mon = "0" + mon;
                }
                if(day < 10){
                    day = "0" + day;
                }

                var div = article;
                div = div.replace(/#id#/g, id);
                div = div.replace(/#title#/g, title);
                div = div.replace(/#year#/g, year);
                div = div.replace(/#mon#/g, mon);
                div = div.replace(/#day#/g, day);
                div = div.replace(/#time#/g, time);
                $('.list_con_rightlist ul').append(div);
            }
            $("html, body").scrollTop(0).animate({scrollTop: $("#to-top").offset().top},1000);
        }
    });
}